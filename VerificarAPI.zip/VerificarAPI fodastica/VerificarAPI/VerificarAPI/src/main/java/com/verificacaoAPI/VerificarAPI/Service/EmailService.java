package com.verificacaoAPI.VerificarAPI.Service;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

    public void enviarEmailVerificacao(String email, String codigo) {
        // Implementação básica - mostra no console
        System.out.println("📧 === EMAIL DE VERIFICAÇÃO ===");
        System.out.println("📨 Para: " + email);
        System.out.println("🔢 Código de verificação: " + codigo);
        System.out.println("⏰ Este código expira em 15 minutos");
        System.out.println("===============================");

        // Em produção, implemente aqui o envio real de email:
        // - JavaMailSender (Spring)
        // - SendGrid API
        // - Amazon SES
        // - Outro serviço de email
    }

    // Método opcional para envio de email de boas-vindas
    public void enviarEmailBoasVindas(String email, String nome) {
        System.out.println("🎉 === EMAIL DE BOAS-VINDAS ===");
        System.out.println("📨 Para: " + email);
        System.out.println("👋 Olá " + nome + ", seja bem-vindo!");
        System.out.println("✅ Seu cadastro foi confirmado com sucesso");
        System.out.println("===============================");
    }
}