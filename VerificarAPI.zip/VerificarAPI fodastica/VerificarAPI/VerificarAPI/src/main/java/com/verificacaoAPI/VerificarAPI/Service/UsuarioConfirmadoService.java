// UsuarioConfirmadoService.java - SERVICE (NOVO)
package com.verificacaoAPI.VerificarAPI.Service;

import com.verificacaoAPI.VerificarAPI.model.UsuarioConfirmado;
import com.verificacaoAPI.VerificarAPI.repository.UsuarioConfirmadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioConfirmadoService {

    @Autowired
    private UsuarioConfirmadoRepository repository;

    public List<UsuarioConfirmado> findAll() {
        return repository.findAll();
    }

    public Optional<UsuarioConfirmado> findByEmail(String email) {
        return repository.findByEmail(email);
    }

    public boolean existsByEmail(String email) {
        return repository.existsByEmail(email);
    }

    public UsuarioConfirmado save(UsuarioConfirmado usuario) {
        return repository.save(usuario);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}