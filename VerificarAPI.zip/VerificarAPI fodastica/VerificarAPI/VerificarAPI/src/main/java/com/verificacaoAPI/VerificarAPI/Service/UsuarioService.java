package com.verificacaoAPI.VerificarAPI.Service; // ← "Service" com S maiúsculo

import com.verificacaoAPI.VerificarAPI.model.Usuario;
import com.verificacaoAPI.VerificarAPI.repository.UsuarioRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {
    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public List<Usuario> findAll() { return repository.findAll(); }

    public Optional<Usuario> findById(Integer id) { return repository.findById(id); }

    public Usuario save(Usuario u) { return repository.save(u); }

    public Usuario update(Integer id, Usuario u) {
        u.setId(id);
        return repository.save(u);
    }

    public void delete(Integer id) { repository.deleteById(id); }

    public boolean emailExiste(String email) { return repository.existsByEmail(email); }
}
