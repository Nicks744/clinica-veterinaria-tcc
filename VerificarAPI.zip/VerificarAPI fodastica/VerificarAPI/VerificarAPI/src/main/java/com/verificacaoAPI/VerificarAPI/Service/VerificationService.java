package com.verificacaoAPI.VerificarAPI.Service;

import com.verificacaoAPI.VerificarAPI.model.UsuarioConfirmado;
import com.verificacaoAPI.VerificarAPI.model.VerificationCode;
import com.verificacaoAPI.VerificarAPI.repository.VerificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class VerificationService {

    @Autowired
    private VerificationRepository verificationRepository;

    @Autowired
    private UsuarioConfirmadoService usuarioConfirmadoService;

    @Autowired
    private EmailService emailService;

    // Gerar código aleatório de 6 dígitos
    private String gerarCodigo() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(999999));
    }

    public boolean enviarCodigoVerificacao(String email) {
        try {
            System.out.println("📨 Solicitando código para: " + email);

            // Deletar códigos existentes para este email
            verificationRepository.deleteByEmail(email);
            System.out.println("🗑️ Códigos antigos deletados para: " + email);

            // Gerar novo código
            String codigo = gerarCodigo();
            VerificationCode verificationCode = new VerificationCode(email, codigo);

            // Salvar no banco
            verificationRepository.save(verificationCode);
            System.out.println("💾 Código salvo no banco: " + codigo + " para: " + email);

            // Enviar email
            emailService.enviarEmailVerificacao(email, codigo);
            System.out.println("✅ Email enviado com sucesso");

            return true;
        } catch (Exception e) {
            System.out.println("❌ Erro ao enviar código: " + e.getMessage());
            return false;
        }
    }

    public boolean verificarCodigo(String email, String codigo, String nome, String cpf, String tipo, String senha) {
        System.out.println("🔍 Iniciando verificação completa para: " + email);
        System.out.println("🔢 Código recebido: " + codigo);

        Optional<VerificationCode> verificationOpt = verificationRepository.findByEmailAndCodigo(email, codigo);

        if (verificationOpt.isPresent()) {
            VerificationCode verification = verificationOpt.get();
            System.out.println("📦 Código encontrado no banco");

            // Debug detalhado do código
            System.out.println("⏰ Data expiração: " + verification.getDataExpiracao());
            System.out.println("🕒 Agora: " + LocalDateTime.now());
            System.out.println("🚫 Utilizado: " + verification.getUtilizado());
            System.out.println("✅ Válido: " + verification.isValid());

            if (verification.isValid()) {
                System.out.println("🎯 Código é válido, marcando como utilizado");
                verification.setUtilizado(true);
                verificationRepository.save(verification);

                // SALVAR COMO USUÁRIO CONFIRMADO
                System.out.println("💾 Salvando usuário confirmado...");
                UsuarioConfirmado usuarioConfirmado = new UsuarioConfirmado();
                usuarioConfirmado.setNome(nome);
                usuarioConfirmado.setCpf(cpf);
                usuarioConfirmado.setEmail(email);
                usuarioConfirmado.setTipo(tipo);
                usuarioConfirmado.setSenha(senha);
                usuarioConfirmado.setCodigoConfirmacao(codigo);

                try {
                    usuarioConfirmadoService.save(usuarioConfirmado);
                    System.out.println("🎉 USUÁRIO CONFIRMADO SALVO COM SUCESSO!");
                    return true;
                } catch (Exception e) {
                    System.out.println("❌ ERRO ao salvar usuário confirmado: " + e.getMessage());
                    return false;
                }
            } else {
                System.out.println("❌ Código inválido (expirado ou já utilizado)");
                return false;
            }
        } else {
            System.out.println("❌ Código NÃO encontrado para este email");
            System.out.println("ℹ️ Verifique se:");
            System.out.println("   - O email está correto: " + email);
            System.out.println("   - O código está correto: " + codigo);
            System.out.println("   - O código foi solicitado recentemente");
            return false;
        }
    }

    public boolean verificarCodigo(String email, String codigo) {
        System.out.println("🔍 Verificação simples para: " + email);

        Optional<VerificationCode> verificationOpt = verificationRepository.findByEmailAndCodigo(email, codigo);

        if (verificationOpt.isPresent()) {
            VerificationCode verification = verificationOpt.get();

            if (verification.isValid()) {
                verification.setUtilizado(true);
                verificationRepository.save(verification);
                System.out.println("✅ Código válido (verificação simples)");
                return true;
            }
        }

        System.out.println("❌ Código inválido (verificação simples)");
        return false;
    }

    public boolean temCodigoAtivo(String email) {
        Optional<VerificationCode> verificationOpt = verificationRepository.findByEmail(email);
        boolean temAtivo = verificationOpt.isPresent() && verificationOpt.get().isValid();
        System.out.println("📋 Tem código ativo para " + email + ": " + temAtivo);
        return temAtivo;
    }

    @Scheduled(fixedRate = 3600000)
    public void limparCodigosExpirados() {
        System.out.println("🧹 Limpando códigos expirados...");
        int deletados = verificationRepository.deleteExpirados();
        System.out.println("🗑️ Códigos expirados removidos: " + deletados);
    }

    // Método adicional para debug
    public void debugCodigo(String email) {
        Optional<VerificationCode> verificationOpt = verificationRepository.findByEmail(email);

        if (verificationOpt.isPresent()) {
            VerificationCode code = verificationOpt.get();
            System.out.println("🐛 DEBUG Código:");
            System.out.println("   Email: " + code.getEmail());
            System.out.println("   Código: " + code.getCodigo());
            System.out.println("   Criado: " + code.getDataCriacao());
            System.out.println("   Expira: " + code.getDataExpiracao());
            System.out.println("   Utilizado: " + code.getUtilizado());
            System.out.println("   Válido: " + code.isValid());
        } else {
            System.out.println("🐛 DEBUG: Nenhum código encontrado para " + email);
        }
    }
}