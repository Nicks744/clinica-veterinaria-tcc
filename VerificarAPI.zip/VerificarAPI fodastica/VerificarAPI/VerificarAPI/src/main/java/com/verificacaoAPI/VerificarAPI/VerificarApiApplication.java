package com.verificacaoAPI.VerificarAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerificarApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(VerificarApiApplication.class, args);
    }
}
