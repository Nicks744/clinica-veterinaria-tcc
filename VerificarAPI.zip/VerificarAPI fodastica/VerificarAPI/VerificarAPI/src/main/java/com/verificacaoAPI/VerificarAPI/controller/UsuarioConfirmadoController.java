// UsuarioConfirmadoController.java - CONTROLLER (NOVO)
package com.verificacaoAPI.VerificarAPI.controller;

import com.verificacaoAPI.VerificarAPI.model.UsuarioConfirmado;
import com.verificacaoAPI.VerificarAPI.Service.UsuarioConfirmadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuarios-confirmados")
public class UsuarioConfirmadoController {

    @Autowired
    private UsuarioConfirmadoService usuarioConfirmadoService;

    // GET ALL
    @GetMapping
    public List<UsuarioConfirmado> getAll() {
        return usuarioConfirmadoService.findAll();
    }

    // GET BY EMAIL
    @GetMapping("/{email}")
    public ResponseEntity<UsuarioConfirmado> getByEmail(@PathVariable String email) {
        Optional<UsuarioConfirmado> usuario = usuarioConfirmadoService.findByEmail(email);
        return usuario.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // VERIFICAR SE EMAIL EXISTE
    @GetMapping("/existe/{email}")
    public ResponseEntity<?> verificarEmail(@PathVariable String email) {
        boolean existe = usuarioConfirmadoService.existsByEmail(email);
        return ResponseEntity.ok().body("{\"existe\": " + existe + "}");
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        usuarioConfirmadoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}