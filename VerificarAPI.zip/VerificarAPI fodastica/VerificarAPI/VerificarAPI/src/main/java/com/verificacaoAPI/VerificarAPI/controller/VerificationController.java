package com.verificacaoAPI.VerificarAPI.controller;

import com.verificacaoAPI.VerificarAPI.Service.VerificationService; // ← "Service" maiúsculo?
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/verificacao")
public class VerificationController {

    @Autowired
    private VerificationService verificationService;

    // Solicitar código de verificação
    @PostMapping("/solicitar")
    public ResponseEntity<?> solicitarCodigo(@RequestParam String email) {
        try {
            boolean sucesso = verificationService.enviarCodigoVerificacao(email);

            Map<String, Object> response = new HashMap<>();
            response.put("sucesso", sucesso);
            response.put("mensagem", sucesso ?
                    "Código de verificação enviado para " + email :
                    "Erro ao enviar código de verificação");
            response.put("email", email);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erro: " + e.getMessage());
        }
    }

    // Verificar código (MÉTODO ATUALIZADO)
    @PostMapping("/verificar")
    public ResponseEntity<?> verificarCodigo(
            @RequestParam String email,
            @RequestParam String codigo,
            @RequestParam String nome,
            @RequestParam String cpf, // NOVO PARÂMETRO
            @RequestParam String tipo, // NOVO PARÂMETRO
            @RequestParam String senha) {

        try {
            boolean valido = verificationService.verificarCodigo(email, codigo, nome, cpf, tipo, senha);

            Map<String, Object> response = new HashMap<>();
            response.put("valido", valido);
            response.put("mensagem", valido ?
                    "Email verificado com sucesso e usuário confirmado!" :
                    "Código inválido ou expirado");
            response.put("email", email);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erro: " + e.getMessage());
        }
    }

    // Método simplificado para apenas verificar (sem confirmar cadastro)
    @PostMapping("/apenas-verificar")
    public ResponseEntity<?> apenasVerificarCodigo(
            @RequestParam String email,
            @RequestParam String codigo) {

        try {
            // Usando a versão simplificada do método (se você criou)
            boolean valido = verificationService.verificarCodigo(email, codigo);

            Map<String, Object> response = new HashMap<>();
            response.put("valido", valido);
            response.put("mensagem", valido ?
                    "Código válido!" :
                    "Código inválido ou expirado");
            response.put("email", email);

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erro: " + e.getMessage());
        }
    }

    // Verificar status de verificação
    @GetMapping("/status")
    public ResponseEntity<?> verificarStatus(@RequestParam String email) {
        try {
            boolean temCodigoAtivo = verificationService.temCodigoAtivo(email);

            Map<String, Object> response = new HashMap<>();
            response.put("email", email);
            response.put("tem_codigo_ativo", temCodigoAtivo);
            response.put("mensagem", temCodigoAtivo ?
                    "Código ativo encontrado" :
                    "Nenhum código ativo encontrado");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erro: " + e.getMessage());
        }
    }
}