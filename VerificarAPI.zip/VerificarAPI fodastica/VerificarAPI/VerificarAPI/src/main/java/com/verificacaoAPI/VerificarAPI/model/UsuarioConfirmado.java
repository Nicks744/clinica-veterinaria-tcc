package com.verificacaoAPI.VerificarAPI.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "usuarios_confirmados")
public class UsuarioConfirmado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false, unique = true)
    private String cpf; // NOVO CAMPO

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String senha;

    @Column(nullable = false)
    private String tipo; // NOVO CAMPO

    private Integer idade;
    private String telefone;
    private String endereco;

    @Column(name = "data_confirmacao", nullable = false)
    private LocalDateTime dataConfirmacao;

    @Column(name = "codigo_confirmacao")
    private String codigoConfirmacao;

    // Construtores
    public UsuarioConfirmado() {
        this.dataConfirmacao = LocalDateTime.now();
    }

    public UsuarioConfirmado(String nome, String cpf, String email, String tipo, String senha, String codigoConfirmacao) {
        this();
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.tipo = tipo;
        this.senha = senha;
        this.codigoConfirmacao = codigoConfirmacao;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCpf() { return cpf; } // NOVO GETTER
    public void setCpf(String cpf) { this.cpf = cpf; } // NOVO SETTER

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getTipo() { return tipo; } // NOVO GETTER
    public void setTipo(String tipo) { this.tipo = tipo; } // NOVO SETTER

    public Integer getIdade() { return idade; }
    public void setIdade(Integer idade) { this.idade = idade; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public LocalDateTime getDataConfirmacao() { return dataConfirmacao; }
    public void setDataConfirmacao(LocalDateTime dataConfirmacao) { this.dataConfirmacao = dataConfirmacao; }

    public String getCodigoConfirmacao() { return codigoConfirmacao; }
    public void setCodigoConfirmacao(String codigoConfirmacao) { this.codigoConfirmacao = codigoConfirmacao; }

    // Método toString para debug
    @Override
    public String toString() {
        return "UsuarioConfirmado{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", email='" + email + '\'' +
                ", tipo='" + tipo + '\'' +
                ", dataConfirmacao=" + dataConfirmacao +
                '}';
    }
}