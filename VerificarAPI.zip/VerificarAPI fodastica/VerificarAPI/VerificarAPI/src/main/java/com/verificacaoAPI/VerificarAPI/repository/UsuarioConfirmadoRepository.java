// UsuarioConfirmadoRepository.java - REPOSITORY (NOVO)
package com.verificacaoAPI.VerificarAPI.repository;

import com.verificacaoAPI.VerificarAPI.model.UsuarioConfirmado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UsuarioConfirmadoRepository extends JpaRepository<UsuarioConfirmado, Long> {
    Optional<UsuarioConfirmado> findByEmail(String email);
    boolean existsByEmail(String email);
}