package com.suaclinica.clinicaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClinicaApiApplication.class, args);
    }

}

