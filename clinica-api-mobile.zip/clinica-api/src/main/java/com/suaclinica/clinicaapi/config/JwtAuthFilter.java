package com.suaclinica.clinicaapi.config;

import com.suaclinica.clinicaapi.service.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component // Define este filtro como um "Bean" do Spring
@RequiredArgsConstructor // Cria um construtor com os campos 'final'
public class JwtAuthFilter extends OncePerRequestFilter { // Filtro que roda UMA VEZ por requisição

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {

        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userEmail;

        // 1. Se não houver header "Authorization" ou não começar com "Bearer ", ignora o filtro.
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        // 2. Extrai o token (remove o "Bearer ")
        jwt = authHeader.substring(7);

        try {
            // 3. Extrai o email de dentro do token
            userEmail = jwtService.extractUsername(jwt);

            // 4. Se o email existe E o usuário ainda não está autenticado no contexto
            if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                // 5. Busca o usuário no banco de dados
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);

                // 6. Valida se o token é válido
                if (jwtService.isTokenValid(jwt, userDetails)) {
                    // 7. Se for válido, cria a autenticação e a coloca no Contexto de Segurança
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null, // Não precisamos de credenciais (senha)
                            userDetails.getAuthorities()
                    );
                    authToken.setDetails(
                            new WebAuthenticationDetailsSource().buildDetails(request)
                    );
                    // Atualiza o contexto de segurança
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                }
            }
            // 8. Passa a requisição para o próximo filtro
            filterChain.doFilter(request, response);

        } catch (Exception e) {
            // Em caso de token inválido (expirado, assinatura errada), apenas limpa o contexto
            SecurityContextHolder.clearContext();
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token JWT inválido ou expirado");
            // Não chama filterChain.doFilter(request, response) para barrar a requisição
        }
    }
}

