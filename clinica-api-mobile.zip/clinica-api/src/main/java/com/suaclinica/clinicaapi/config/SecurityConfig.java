package com.suaclinica.clinicaapi.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final AuthenticationProvider authenticationProvider;

    /**
     * Configura a cadeia de filtros de segurança do Spring.
     * Esta é a configuração de segurança principal da API.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // 1. Desabilita o CSRF (desnecessário para APIs REST stateless)
                .csrf(csrf -> csrf.disable())

                // 2. Define as regras de autorização
                .authorizeHttpRequests(auth -> auth
                        // Permite acesso público aos endpoints de /api/auth/** (login e registro)
                        .requestMatchers("/api/auth/**").permitAll()
                        // Qualquer outra requisição deve ser autenticada
                        .anyRequest().authenticated()
                )

                // 3. Define a política de sessão como STATELESS (sem estado)
                // A API não guardará sessões; cada requisição é validada pelo token.
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // 4. Define o provedor de autenticação (ApplicationConfig)
                .authenticationProvider(authenticationProvider)

                // 5. Adiciona o nosso filtro de JWT ANTES do filtro padrão do Spring
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}

