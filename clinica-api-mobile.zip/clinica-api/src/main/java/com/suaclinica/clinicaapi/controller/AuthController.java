package com.suaclinica.clinicaapi.controller;

import com.suaclinica.clinicaapi.dto.AuthResponse;
import com.suaclinica.clinicaapi.dto.LoginRequest;
import com.suaclinica.clinicaapi.dto.RegistroRequest;
import com.suaclinica.clinicaapi.model.Usuario;
import com.suaclinica.clinicaapi.repository.UsuarioRepository;
import com.suaclinica.clinicaapi.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth") // Rota base para este controlador
@RequiredArgsConstructor
public class AuthController {

    // Injeção das dependências
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    /**
     * Endpoint para REGISTRAR um novo usuário
     */
    @PostMapping("/registro")
    public ResponseEntity<?> registrar(@RequestBody RegistroRequest request) {

        // 1. Verifica se o email já existe
        if (usuarioRepository.existsByEmail(request.email())) {
            return ResponseEntity
                    .badRequest()
                    .body("Erro: Este e-mail já está em uso!");
        }

        // 2. Cria o novo usuário
        Usuario novoUsuario = Usuario.builder()
                .nome(request.nome())
                .email(request.email())
                // 3. CRIPTOGRAFA a senha ANTES de salvar!
                .senha(passwordEncoder.encode(request.senha()))
                .build();

        // 4. Salva o usuário no banco
        usuarioRepository.save(novoUsuario);

        // 5. Gera um token para o usuário recém-registrado (Login automático)
        //    Faz o "cast" explícito para (UserDetails) para o compilador encontrar o método.
        String token = jwtService.generateToken((UserDetails) novoUsuario);

        // 6. Retorna o token, nome e email
        //    (Corrigido para enviar 3 argumentos, como o DTO AuthResponse espera)
        return ResponseEntity.ok(new AuthResponse(token, novoUsuario.getNome(), novoUsuario.getEmail()));
    }

    /**
     * Endpoint para LOGAR um usuário existente
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            // 1. Tenta autenticar o usuário
            //    Isso chama o ApplicationConfig -> UserDetailsService -> UsuarioRepository
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.email(),
                            request.senha()
                    )
            );

            // 2. Se a autenticação for bem-sucedida, busca o UserDetails
            var userDetails = (UserDetails) authentication.getPrincipal();

            // 3. Gera o token JWT
            var jwtToken = jwtService.generateToken(userDetails);

            // 4. Busca os dados específicos do usuário (para pegar nome e email)
            var usuario = (Usuario) userDetails;

            // 5. Retorna o token, nome e email
            //    (Corrigido para enviar 3 argumentos)
            return ResponseEntity.ok(new AuthResponse(jwtToken, usuario.getNome(), usuario.getEmail()));

        } catch (AuthenticationException e) {
            // 6. Se a autenticação falhar (senha errada, usuário não existe)
            return ResponseEntity
                    .status(401) // 401 Unauthorized
                    .body("Erro: E-mail ou senha inválidos.");
        }
    }
}

