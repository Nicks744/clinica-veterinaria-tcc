package com.suaclinica.clinicaapi.dto;

// Define o formato JSON que a API retorna após login/registro
// Este formato com 3 campos corrige o erro de compilação
public record AuthResponse(String token, String nomeUsuario, String email) {
}

