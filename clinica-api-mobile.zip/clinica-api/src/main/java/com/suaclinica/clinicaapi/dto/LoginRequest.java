package com.suaclinica.clinicaapi.dto;

// Define o formato JSON que a API espera para /login
// Java 17+ "record" é uma classe imutável simples
public record LoginRequest(String email, String senha) {
}

