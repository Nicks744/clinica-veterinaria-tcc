package com.suaclinica.clinicaapi.dto;

// Define o formato JSON que a API espera para /registro
public record RegistroRequest(String nome, String email, String senha) {
}

