package com.suaclinica.clinicaapi.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Data // Gera Getters, Setters, toString, equals, hashCode
@Builder // Padrão de projeto Builder, para construir o objeto
@NoArgsConstructor // Gera um construtor sem argumentos
@AllArgsConstructor // Gera um construtor com todos os argumentos
@Entity // Define esta classe como uma entidade JPA (tabela no banco)
@Table(name = "usuarios") // Nome da tabela no banco
public class Usuario implements UserDetails { // Implementa UserDetails para o Spring Security

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Chave primária auto-increment
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false, unique = true) // Email deve ser único
    private String email;

    @Column(nullable = false)
    private String senha;

    // --- Métodos do UserDetails ---
    // Spring Security usa o email como "username"
    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public String getPassword() {
        return this.senha;
    }

    // Para este exemplo, não estamos usando Roles (ex: ADMIN, USER)
    // Então retornamos uma lista vazia.
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // Conta nunca expira
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Conta nunca é bloqueada
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Credenciais (senha) nunca expiram
    }

    @Override
    public boolean isEnabled() {
        return true; // Conta está sempre habilitada
    }
}

