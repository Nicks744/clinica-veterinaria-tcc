package com.suaclinica.clinicaapi.repository;

import com.suaclinica.clinicaapi.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // O Spring Data JPA cria a consulta automaticamente pelo nome do método
    // "Encontre um usuário pelo seu email"
    Optional<Usuario> findByEmail(String email);

    // "Verifica se existe um usuário pelo seu email"
    boolean existsByEmail(String email);
}

